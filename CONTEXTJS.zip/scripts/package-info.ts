type PackageInfo = { name: string, path?: string };

export default PackageInfo;